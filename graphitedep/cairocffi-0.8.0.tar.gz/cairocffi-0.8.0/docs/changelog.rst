.. currentmodule:: cairocffi
.. include:: ../CHANGES
